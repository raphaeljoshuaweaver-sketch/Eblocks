
import { GoogleGenAI, Type } from "@google/genai";

export async function getBuildingSuggestion(theme: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `You are an Eblocks (Roblox-like) building expert. The user wants to build something with the theme: "${theme}". 
    Suggest a creative 5-step build guide using simple blocks like Grass, Stone, Wood, and Glass. 
    Keep it encouraging and short.`,
    config: {
      temperature: 0.7,
      maxOutputTokens: 500,
    },
  });

  return response.text;
}

export async function getQuickAdvice(action: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `User is playing Eblocks and just: "${action}". Give a very short, witty Roblox-style comment or tip. Max 10 words.`,
  });
  return response.text;
}
