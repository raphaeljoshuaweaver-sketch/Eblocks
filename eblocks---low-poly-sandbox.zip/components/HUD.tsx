import React from 'react';
import { BlockType, BLOCK_COLORS } from '../types';

interface HUDProps {
  selectedBlockType: BlockType;
  setSelectedBlockType: (type: BlockType) => void;
  lastAction: string;
}

const HUD: React.FC<HUDProps> = ({ selectedBlockType, setSelectedBlockType, lastAction }) => {
  const blockTypes = Object.values(BlockType);

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-6">
      {/* Top Bar */}
      <div className="flex justify-between items-start pointer-events-auto">
        <div className="bg-black/60 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/20 shadow-2xl">
          <h1 className="text-2xl font-black tracking-tighter text-yellow-400">EBLOCKS <span className="text-white text-sm font-medium">BETA</span></h1>
          <p className="text-[10px] text-white/50 uppercase tracking-widest">Low-Poly Sandbox Engine</p>
        </div>
      </div>

      {/* Middle Alerts */}
      <div className="flex flex-col items-center justify-center h-full">
         <div className="bg-black/20 backdrop-blur-[2px] px-4 py-1 rounded-full text-xs animate-pulse">
            {lastAction}
         </div>
      </div>

      {/* Bottom Inventory Bar */}
      <div className="flex flex-col items-center gap-4">
        <div className="bg-black/60 backdrop-blur-xl p-3 rounded-3xl border border-white/10 flex gap-2 pointer-events-auto shadow-2xl">
          {blockTypes.map((type, index) => (
            <button
              key={type}
              onClick={() => setSelectedBlockType(type)}
              className={`
                relative w-14 h-14 rounded-xl transition-all flex flex-col items-center justify-center gap-1 group
                ${selectedBlockType === type ? 'ring-4 ring-yellow-400 scale-110 shadow-lg' : 'hover:bg-white/10'}
              `}
            >
              <div 
                className="w-8 h-8 rounded-md shadow-inner" 
                style={{ backgroundColor: BLOCK_COLORS[type] }}
              />
              <span className="text-[9px] font-bold uppercase opacity-80">{type}</span>
              <span className="absolute -top-2 -right-2 bg-yellow-400 text-black text-[10px] font-black w-5 h-5 flex items-center justify-center rounded-full shadow-md">
                {index + 1}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HUD;