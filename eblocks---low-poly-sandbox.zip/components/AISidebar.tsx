
import React, { useState, useEffect } from 'react';
import { getBuildingSuggestion, getQuickAdvice } from '../services/geminiService';

interface AISidebarProps {
  onClose: () => void;
  lastAction: string;
}

const AISidebar: React.FC<AISidebarProps> = ({ onClose, lastAction }) => {
  const [suggestion, setSuggestion] = useState<string>("");
  const [theme, setTheme] = useState("");
  const [loading, setLoading] = useState(false);
  const [advice, setAdvice] = useState("Keep building, master!");

  useEffect(() => {
    const fetchAdvice = async () => {
      try {
        const text = await getQuickAdvice(lastAction);
        setAdvice(text || "Looking good!");
      } catch (e) {
        console.error(e);
      }
    };
    fetchAdvice();
  }, [lastAction]);

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!theme) return;
    setLoading(true);
    try {
      const result = await getBuildingSuggestion(theme);
      setSuggestion(result || "No suggestion found.");
    } catch (err) {
      setSuggestion("Error connecting to Eblocks AI. Check your API key.");
    }
    setLoading(false);
  };

  return (
    <div className="absolute right-0 top-0 h-full w-full max-w-sm bg-[#1a1a1a]/95 backdrop-blur-2xl border-l border-white/10 shadow-2xl flex flex-col z-50 animate-in slide-in-from-right duration-300">
      <div className="p-6 border-b border-white/10 flex justify-between items-center bg-gradient-to-r from-indigo-900/40 to-transparent">
        <div>
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <i className="fa-solid fa-robot text-indigo-400"></i>
            E-BOT BUILDER
          </h2>
          <p className="text-xs text-indigo-300/60 font-medium">Building Intelligence v1.0</p>
        </div>
        <button onClick={onClose} className="w-10 h-10 hover:bg-white/10 rounded-full flex items-center justify-center transition-colors">
          <i className="fa-solid fa-times"></i>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Quick Advice Bubble */}
        <div className="bg-indigo-600/20 p-4 rounded-2xl border border-indigo-500/30">
          <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider mb-1">Current Status</p>
          <p className="text-sm italic text-indigo-100">"{advice}"</p>
        </div>

        <div className="space-y-4">
          <label className="text-xs font-bold uppercase text-white/40 tracking-widest">What should we build?</label>
          <form onSubmit={handleAsk} className="relative">
            <input 
              value={theme}
              onChange={(e) => setTheme(e.target.value)}
              placeholder="e.g. A tiny castle, a rocket..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all pr-12"
            />
            <button 
              type="submit"
              disabled={loading}
              className="absolute right-2 top-2 w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center hover:bg-indigo-400 transition-colors disabled:opacity-50"
            >
              {loading ? (
                <i className="fa-solid fa-circle-notch animate-spin"></i>
              ) : (
                <i className="fa-solid fa-paper-plane text-xs"></i>
              )}
            </button>
          </form>
        </div>

        {suggestion && (
          <div className="bg-white/5 rounded-2xl p-6 border border-white/10 animate-in fade-in slide-in-from-bottom-2">
            <h3 className="text-xs font-black text-indigo-400 uppercase tracking-widest mb-4">Blueprints</h3>
            <div className="prose prose-invert prose-sm">
              <p className="text-white/80 leading-relaxed whitespace-pre-wrap">{suggestion}</p>
            </div>
          </div>
        )}

        {!suggestion && !loading && (
          <div className="flex flex-col items-center justify-center py-12 text-white/20">
            <i className="fa-solid fa-cubes text-4xl mb-4"></i>
            <p className="text-xs font-medium">Ready for instructions...</p>
          </div>
        )}
      </div>

      <div className="p-6 bg-black/40 text-[10px] text-white/30 text-center border-t border-white/5">
        AI models can make mistakes. Always double check your blocks!
      </div>
    </div>
  );
};

export default AISidebar;
