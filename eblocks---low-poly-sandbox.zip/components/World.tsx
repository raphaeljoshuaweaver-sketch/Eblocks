
import React from 'react';
import { ThreeEvent } from '@react-three/fiber';
import { BlockData, BLOCK_COLORS, BlockType } from '../types';
import Player from './Player';

interface WorldProps {
  blocks: BlockData[];
  addBlock: (x: number, y: number, z: number) => void;
  removeBlock: (x: number, y: number, z: number) => void;
}

const World: React.FC<WorldProps> = ({ blocks, addBlock, removeBlock }) => {
  const handleInteraction = (e: ThreeEvent<MouseEvent>, position: [number, number, number]) => {
    e.stopPropagation();
    
    if (e.button === 0) { // Left Click - Place
      const [x, y, z] = position;
      const dir = [
        Math.round(e.face!.normal.x),
        Math.round(e.face!.normal.y),
        Math.round(e.face!.normal.z)
      ];
      addBlock(x + dir[0], y + dir[1], z + dir[2]);
    } else if (e.button === 2) { // Right Click - Remove
      const [x, y, z] = position;
      removeBlock(x, y, z);
    }
  };

  return (
    <group>
      <Player blocks={blocks} />
      {blocks.map((block) => (
        <mesh 
          key={block.id} 
          position={block.position} 
          onPointerDown={(e) => handleInteraction(e, block.position)}
          castShadow 
          receiveShadow
        >
          <boxGeometry args={[1, 1, 1]} />
          <meshStandardMaterial 
            color={BLOCK_COLORS[block.type]} 
            flatShading={true}
            roughness={0.8}
            metalness={0.1}
            transparent={block.type === BlockType.GLASS}
            opacity={block.type === BlockType.GLASS ? 0.4 : 1}
          />
        </mesh>
      ))}
    </group>
  );
};

export default World;
