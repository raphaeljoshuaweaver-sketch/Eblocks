import React, { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { BlockData } from '../types';

interface PlayerProps {
  blocks: BlockData[];
}

const Player: React.FC<PlayerProps> = ({ blocks }) => {
  const { camera } = useThree();
  
  // Physics constants
  const GRAVITY = -25;
  const JUMP_FORCE = 10;
  const MOVE_SPEED = 6;
  const PLAYER_RADIUS = 0.35;
  const PLAYER_HEIGHT = 1.8;
  const PLAYER_EYE_LEVEL = 1.6;

  const velocity = useRef(new THREE.Vector3(0, 0, 0));
  const keys = useRef<{ [key: string]: boolean }>({});
  const isGrounded = useRef(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => (keys.current[e.code] = true);
    const handleKeyUp = (e: KeyboardEvent) => (keys.current[e.code] = false);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    // Set starting position above the floor
    camera.position.set(0, 5, 5);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [camera]);

  // AABB Collision helper
  const checkCollision = (pos: THREE.Vector3) => {
    // Player AABB centered at (pos.x, pos.z) and reaching from pos.y - height up to pos.y
    const pMinX = pos.x - PLAYER_RADIUS;
    const pMaxX = pos.x + PLAYER_RADIUS;
    const pMinY = pos.y - PLAYER_HEIGHT;
    const pMaxY = pos.y;
    const pMinZ = pos.z - PLAYER_RADIUS;
    const pMaxZ = pos.z + PLAYER_RADIUS;

    for (const block of blocks) {
      const bPos = block.position;
      // Block is 1x1x1 centered at position
      const bMinX = bPos[0] - 0.5;
      const bMaxX = bPos[0] + 0.5;
      const bMinY = bPos[1] - 0.5;
      const bMaxY = bPos[1] + 0.5;
      const bMinZ = bPos[2] - 0.5;
      const bMaxZ = bPos[2] + 0.5;

      const overlapX = pMinX < bMaxX && pMaxX > bMinX;
      const overlapY = pMinY < bMaxY && pMaxY > bMinY;
      const overlapZ = pMinZ < bMaxZ && pMaxZ > bMinZ;

      if (overlapX && overlapY && overlapZ) {
        return true;
      }
    }
    return false;
  };

  useFrame((state, delta) => {
    // 1. Movement Direction
    const camDir = new THREE.Vector3();
    camera.getWorldDirection(camDir);
    camDir.y = 0;
    camDir.normalize();

    const camSide = new THREE.Vector3().crossVectors(camDir, new THREE.Vector3(0, 1, 0)).normalize();
    
    const inputDir = new THREE.Vector3(0, 0, 0);
    if (keys.current['KeyW']) inputDir.add(camDir);
    if (keys.current['KeyS']) inputDir.sub(camDir);
    if (keys.current['KeyA']) inputDir.sub(camSide);
    if (keys.current['KeyD']) inputDir.add(camSide);
    
    if (inputDir.length() > 0) {
      inputDir.normalize().multiplyScalar(MOVE_SPEED * delta);
    }

    // 2. Physics & Jump
    velocity.current.y += GRAVITY * delta;
    if (keys.current['Space'] && isGrounded.current) {
      velocity.current.y = JUMP_FORCE;
      isGrounded.current = false;
    }

    // 3. Collision Resolution (Axis by Axis)
    const currentPos = camera.position.clone();
    
    // Resolve Y (Vertical)
    const nextY = currentPos.clone();
    nextY.y += velocity.current.y * delta;
    if (checkCollision(nextY)) {
      if (velocity.current.y < 0) {
        isGrounded.current = true;
      }
      velocity.current.y = 0;
      // If we hit something, don't move along Y
    } else {
      camera.position.y = nextY.y;
      isGrounded.current = false;
    }

    // Resolve X
    const nextX = camera.position.clone();
    nextX.x += inputDir.x;
    if (!checkCollision(nextX)) {
      camera.position.x = nextX.x;
    }

    // Resolve Z
    const nextZ = camera.position.clone();
    nextZ.z += inputDir.z;
    if (!checkCollision(nextZ)) {
      camera.position.z = nextZ.z;
    }

    // Fall out protection
    if (camera.position.y < -20) {
      camera.position.set(0, 10, 0);
      velocity.current.y = 0;
    }
  });

  return null;
};

export default Player;