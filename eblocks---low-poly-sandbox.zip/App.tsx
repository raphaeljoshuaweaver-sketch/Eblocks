import React, { useState, useEffect, useCallback, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Sky, PointerLockControls, Stars, PerspectiveCamera } from '@react-three/drei';
import * as THREE from 'three';
import { BlockType, BlockData } from './types';
import World from './components/World';
import HUD from './components/HUD';

const App: React.FC = () => {
  const [blocks, setBlocks] = useState<BlockData[]>([]);
  const [selectedBlockType, setSelectedBlockType] = useState<BlockType>(BlockType.STONE);
  const [lastAction, setLastAction] = useState<string>("Started building!");

  // Initialize a basic floor
  useEffect(() => {
    const initialBlocks: BlockData[] = [];
    for (let x = -10; x <= 10; x++) {
      for (let z = -10; z <= 10; z++) {
        initialBlocks.push({
          id: `${x}-0-${z}`,
          position: [x, 0, z],
          type: BlockType.GRASS,
        });
      }
    }
    setBlocks(initialBlocks);
  }, []);

  // Keyboard block switching
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const keyMap: Record<string, BlockType> = {
        'Digit1': BlockType.GRASS,
        'Digit2': BlockType.DIRT,
        'Digit3': BlockType.STONE,
        'Digit4': BlockType.WOOD,
        'Digit5': BlockType.LEAVES,
        'Digit6': BlockType.GLASS,
        'Digit7': BlockType.BRICK,
      };
      if (keyMap[e.code]) {
        setSelectedBlockType(keyMap[e.code]);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const addBlock = useCallback((x: number, y: number, z: number) => {
    const id = `${x}-${y}-${z}`;
    setBlocks((prev) => {
      if (prev.find((b) => b.id === id)) return prev;
      setLastAction(`Placed a ${selectedBlockType} block`);
      return [...prev, { id, position: [x, y, z], type: selectedBlockType }];
    });
  }, [selectedBlockType]);

  const removeBlock = useCallback((x: number, y: number, z: number) => {
    const id = `${x}-${y}-${z}`;
    setBlocks((prev) => {
      const exists = prev.find((b) => b.id === id);
      if (exists && exists.position[1] === 0 && exists.type === BlockType.GRASS) return prev; // Don't delete floor
      if (exists) setLastAction(`Removed a block`);
      return prev.filter((b) => b.id !== id);
    });
  }, []);

  return (
    <div className="w-full h-full relative font-sans text-white overflow-hidden">
      {/* 3D Game Engine */}
      <div className="absolute inset-0 cursor-crosshair">
        <Canvas shadows>
          <PerspectiveCamera makeDefault position={[5, 5, 5]} fov={75} />
          <Sky sunPosition={[100, 20, 100]} />
          <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1} castShadow />
          <directionalLight 
            position={[5, 10, 5]} 
            intensity={1} 
            castShadow 
            shadow-mapSize={[1024, 1024]} 
          />
          
          <Suspense fallback={null}>
            <World 
              blocks={blocks} 
              addBlock={addBlock} 
              removeBlock={removeBlock} 
            />
          </Suspense>

          <PointerLockControls />
        </Canvas>
      </div>

      {/* Overlay UI */}
      <HUD 
        selectedBlockType={selectedBlockType} 
        setSelectedBlockType={setSelectedBlockType} 
        lastAction={lastAction}
      />

      {/* Crosshair */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
        <div className="w-4 h-4 border-2 border-white rounded-full opacity-50"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-1 bg-white rounded-full"></div>
      </div>

      {/* Instructions */}
      <div className="absolute bottom-4 left-4 bg-black/40 backdrop-blur-md p-3 rounded-xl border border-white/10 text-xs">
        <p>🖱️ Click to place • Right-click to remove</p>
        <p>⌨️ WASD to move • Space to jump</p>
        <p>⌨️ 1-7 to switch blocks</p>
        <p>🖱️ Click screen to lock mouse</p>
      </div>
    </div>
  );
};

export default App;