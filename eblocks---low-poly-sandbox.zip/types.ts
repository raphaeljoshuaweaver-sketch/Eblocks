
export type Vector3 = [number, number, number];

export enum BlockType {
  GRASS = 'grass',
  DIRT = 'dirt',
  STONE = 'stone',
  WOOD = 'wood',
  LEAVES = 'leaves',
  GLASS = 'glass',
  BRICK = 'brick',
}

export interface BlockData {
  id: string;
  position: Vector3;
  type: BlockType;
}

export interface GameState {
  blocks: BlockData[];
  selectedBlockType: BlockType;
  isBuilding: boolean;
  isFlying: boolean;
}

export const BLOCK_COLORS: Record<BlockType, string> = {
  [BlockType.GRASS]: '#4caf50',
  [BlockType.DIRT]: '#795548',
  [BlockType.STONE]: '#9e9e9e',
  [BlockType.WOOD]: '#5d4037',
  [BlockType.LEAVES]: '#2e7d32',
  [BlockType.GLASS]: '#bbdefb',
  [BlockType.BRICK]: '#e57373',
};
